from asyncio.windows_events import NULL
import email
from multiprocessing import context
from re import A
from django.db.models import Max,Sum
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.shortcuts import render, HttpResponse, redirect
from flask import render_template
from .models import Person,Item_Master,emp_setup
from dppsales.models import customer_Ledger,unit_master
from cus_leads.models import inquiry_setup,IndiaMart_leads
from django.db.models import Max
from django.urls import reverse
import pandas as pd, json
from datetime import date,datetime
from django.core.paginator import Paginator
from django.contrib.auth.forms import UserCreationForm  
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User,Group

@login_required
def index(request):
	dr_amount=customer_Ledger.objects.filter(bal_type="Dr").filter(transaction_type="Sale Bill").aggregate(Sum('item_grand_total'))['item_grand_total__sum']
	Tot_Cust = Person.objects.all().count()
	Tot_emp = emp_setup.objects.all().count()
	tot_leads=inquiry_setup.objects.all().count()
	Tot_unread_leads = IndiaMart_leads.objects.filter(e_status="Unread").count()
	context={'totcustomers':Tot_Cust,
			'totemp':Tot_emp,
			'totleads':tot_leads,
			'tot_sale':dr_amount,
			'unreadLeads':Tot_unread_leads
			}
	return render(request, 'index.html', context)


def redirect_view(request):
	response = redirect('/redirect-success/')
	return response

def all_emp(request):
	data=Person.objects.all().order_by('cust_id')
	Tot_Cust = Person.objects.all().count()
	Regular_Cust = Person.objects.filter(cust_Type='Regular').count()
	Contract_Cust = Person.objects.filter(cust_Type='Temporary').count()
	NEW_Cust = Person.objects.filter(cust_Type='Lead').count()
	context={
		'emp':data,
		'Tot_count_cus':Tot_Cust,
		'Reg_cus':Regular_Cust,
		'Con_cus':Contract_Cust,
		'new_cus':NEW_Cust
	}
	return render(request, 'view.html', context=context)
	
def add_emp(request):
	if request.method =="POST":
		res = Person.objects.filter().aggregate(max_id=Max('cust_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		c_id=p+1
		c_code=request.POST['cust_code']
		Party_name=request.POST['party_name']
		Party_address=request.POST['cust_address']
		Party_city=request.POST['cust_city']
		cust_pin=request.POST['cust_pin']
		Party_ph=request.POST['cust_ph']
		cust_email=request.POST['cust_email']
		Party_GST=request.POST['cust_GST']
		contact_per=request.POST['contact_per']
		cust_type=request.POST['Cust_type']
		opening_bal=request.POST['op_bal']
		bal_type=request.POST['bal_type']
		new_emp=Person(cust_id=c_id,cust_code=c_code,cust_name=Party_name,cust_address=Party_address,cust_city=Party_city,cust_ph=Party_ph,cust_Gst_No=Party_GST,contact_per=contact_per,cust_Type=cust_type,cust_email=cust_email,opening_bal=opening_bal,bal_type=bal_type,cust_pin=cust_pin)
		new_emp.save()

		res = customer_Ledger.objects.filter().aggregate(max_id=Max('s_id'))

		p=res.get('max_id')
		if p is None:
			p=0
		c_id=p+1
		s_date='2022-04-01'
		cust_name=request.POST['party_name']
		party_name=request.POST['party_name']
		
		cust_city=request.POST['cust_city']
		cust_address=request.POST['cust_address']
		cust_mobile=request.POST['cust_ph']
		cust_Gst=request.POST['cust_GST']
		
		item_grand_total=float(request.POST['op_bal'])
		item_after_tax_total=float(request.POST['op_bal'])
		a_type=request.POST['bal_type']

		new_led=customer_Ledger(s_id=c_id,s_date=s_date,cust_name=cust_name,party_name=party_name,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,item_grand_total=item_grand_total,item_after_tax_total=item_after_tax_total,bal_type=a_type)
		new_led.save()

		return HttpResponse('Saved'+ str(c_id))
	elif request.method=='GET':
		return render(request,'addemp.html')
	else:
		return HttpResponse('Exception Occured')
	
	
def remove_emp(request, emp_id=0):
	if emp_id:
		try:
			emp_to_be_removed = Person.objects.get(cust_id=emp_id)
			emp_to_be_removed.delete()
			return HttpResponse('Successfully Deleted')
		except:
			return HttpResponse('Enter id')
	data=Person.objects.all()
	context={
		"emp":data
	}
	return render(request, 'removeemp.html', context)
	
def edit_emp(request, emp_id=0):
	if emp_id:
		emps = Person.objects.filter(cust_id =emp_id)
		context={
			'emp':emps
			}
		return render(request, 'filteremp.html', context)
def update_emp(request, emp_id=0):
	if emp_id:
		if request.method =="POST":
			emp_to_be_removed = Person.objects.get(cust_id=emp_id)
			emp_to_be_removed.delete()
			c_id=emp_id
			c_code=request.POST['cust_code']
			Party_name=request.POST['party_name']
			Party_address=request.POST['cust_address']
			Party_city=request.POST['cust_city']
			Party_ph=request.POST['cust_ph']
			cust_pin=request.POST['cust_pin']
			Party_GST=request.POST['cust_GST']
			contact_per=request.POST['contact_per']
			cust_type=request.POST['Cust_type']
			new_emp=Person(cust_id=c_id,cust_code=c_code,cust_name=Party_name,cust_address=Party_address,cust_city=Party_city,cust_ph=Party_ph,cust_Gst_No=Party_GST,contact_per=contact_per,cust_Type=cust_type,cust_pin=cust_pin)
			new_emp.save()
			#messages.info(request, 'Updated successfully!')
			return redirect('/all_emp')
		elif request.method=='GET':
			return render(request,'filteremp.html')
		else:
			return HttpResponse('Exception Occured')	
def filter_emp(request):	
	if request.method =="POST":
		first_name=request.POST['cust_name']
		emps=Person.objects.all()
		if first_name:
			emps=emps.filter(cust_name__icontains=first_name)
			#emps=emps.filter(Q(first_name__icontains = first_name)|Q(last_name__icontains=last_name))
			context={
				'emp':emps
			}
		else:
			data=Person.objects.all().order_by('cust_id')
			Tot_Cust = Person.objects.all().count()
			Regular_Cust = Person.objects.filter(cust_Type='Regular').count()
			Contract_Cust = Person.objects.filter(cust_Type='Contract').count()
			NEW_Cust = Person.objects.filter(cust_Type='New').count()
			context={
				'emp':data,
				'Tot_count_cus':Tot_Cust,
				'Reg_cus':Regular_Cust,
				'Con_cus':Contract_Cust,
				'new_cus':NEW_Cust
					}			
			return redirect('/all_emp')
		return render(request, 'view.html', context)
		
	elif request.method=='GET':
		return render(request, 'view.html', context)
	else:
		return HttpResponse('An Exception')

def item_setup(request):
	
	Tot_items = Item_Master.objects.all().count()
	Regular_Cust = Person.objects.filter(cust_Type='Regular').count()
	Contract_Cust = Person.objects.filter(cust_Type='Contract').count()
	NEW_Cust = Person.objects.filter(cust_Type='New').count()
	data=Item_Master.objects.all().order_by('item_id')
	context={
		'emp':data,
		'Tot_count_cus':Tot_items,
		'Reg_cus':Regular_Cust,
		'Con_cus':Contract_Cust,
		'new_cus':NEW_Cust
	}
	return render(request, 'item_setup.html', context=context)

def add_item(request):
	unit_name=unit_master.objects.all()
	context={'u_name':unit_name}
	if request.method =="POST":
		res = Item_Master.objects.filter().aggregate(max_id=Max('item_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		item_id=p+1
		
		item_code=request.POST['item_code']
		item_name=request.POST['item_name']
		item_unit=request.POST['item_unit']
		e_field=request.POST['e_field']
		item_cat=request.POST['item_cat']
		qty_in_hand=int(request.POST['qty_in_hand'])
		qty_warning=int(request.POST['qty_warning'])
		sale_price=request.POST['sale_price']
		pur_price=request.POST['pur_price']
		e_int_f=float(request.POST['e_int_f'])
		item_desc=request.POST['item_desc']
		new_item=Item_Master(item_id=item_id,item_code=item_code,item_name=item_name,item_unit=item_unit,e_field=e_field,item_cat=item_cat,qty_in_hand=qty_in_hand,qty_warning=qty_warning,sale_price=sale_price,pur_price=pur_price,e_int_f=e_int_f,item_desc=item_desc)
		new_item.save()
		data=Item_Master.objects.all().order_by('item_id')
		context={
		'emp':data,
			}
		return render(request,'item_setup.html',context)
	elif request.method=='GET':
		return render(request,'add_item.html',context)
	else:
		return HttpResponse('Exception Occured')
	
def remove_items(request, emp_id=0):
	if emp_id:
		try:
			emp_to_be_removed = Item_Master.objects.get(item_id=emp_id)
			emp_to_be_removed.delete()
			return HttpResponse('Successfully Deleted')
		except:
			return HttpResponse('Enter id')
	data=Person.objects.all()
	context={
		"emp":data
	}
	return render(request, 'removeemp.html', context)

def edit_items(request, emp_id=0):
	if emp_id:
		emps = Item_Master.objects.filter(item_id =emp_id)
		context={
			'emp':emps
			}
		return render(request, 'filteritem.html', context)
def update_items(request, emp_id=0):
	if emp_id:
		if request.method =="POST":
			emp_to_be_removed = Item_Master.objects.get(item_id=emp_id)
			emp_to_be_removed.delete()
			c_id=emp_id
			item_code=request.POST['item_code']
			item_name=request.POST['item_name']
			item_unit=request.POST['item_unit']
			e_field=request.POST['e_field']
			item_cat=request.POST['item_cat']
			qty_in_hand=request.POST['qty_in_hand']
			qty_warning=request.POST['qty_warning']
			sale_price=request.POST['sale_price']
			pur_price=request.POST['pur_price']
			e_int_f=request.POST['e_int_f']
			new_item=Item_Master(item_id=emp_id,item_code=item_code,item_name=item_name,item_unit=item_unit,e_field=e_field,item_cat=item_cat,qty_in_hand=qty_in_hand,qty_warning=qty_warning,sale_price=sale_price,pur_price=pur_price,e_int_f=e_int_f)
			new_item.save()
			
			return redirect('/item_setup')
		elif request.method=='GET':
			return render(request,'filteritem.html')
		else:
			return HttpResponse('Exception Occured')	

def filter_item(request):	
	if request.method =="POST":
		first_name=request.POST['item_name']
		emps=Item_Master.objects.all()
		if first_name:
			emps=emps.filter(item_name__icontains=first_name)
			#emps=emps.filter(Q(first_name__icontains = first_name)|Q(last_name__icontains=last_name))
			context={
				'emp':emps
			}
		else:
			data=Item_Master.objects.all().order_by('item_id')
			Tot_items = Item_Master.objects.all().count()
			Regular_Cust = Person.objects.filter(cust_Type='Regular').count()
			Contract_Cust = Person.objects.filter(cust_Type='Contract').count()
			NEW_Cust = Person.objects.filter(cust_Type='New').count()
			context={
				'emp':data,
				'Tot_count_cus':Tot_items,
				'Reg_cus':Regular_Cust,
				'Con_cus':Contract_Cust,
				'new_cus':NEW_Cust
					}			
			return redirect('/item_setup')
		return render(request, 'item_setup.html', context)
		
	elif request.method=='GET':
		return render(request, 'item_setup.html', context)
	else:
		return HttpResponse('An Exception')


def emp_setup1(request): #This is the main display page of employees
	
	Tot_Cust = emp_setup.objects.all().count()
	Regular_Cust = emp_setup.objects.filter(emp_status='Working').count()
	Contract_Cust = emp_setup.objects.filter(emp_status='Retired').count()
	NEW_Cust = emp_setup.objects.filter(emp_credit='Yes').count()
	data=emp_setup.objects.all().order_by('emp_id')
	context={
		'emp':data,
		'Tot_count_cus':Tot_Cust,
		'Reg_cus':Regular_Cust,
		'Con_cus':Contract_Cust,
		'new_cus':NEW_Cust
	}
	return render(request, 'emp_setup.html', context=context)

def add_emp_new(request): #This is add employee module
	if request.method =="POST":
		res = emp_setup.objects.filter().aggregate(max_id=Max('emp_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		emp_id=p+1
		emp_code=request.POST['emp_code']
		emp_name=request.POST['emp_name']
		emp_dep=request.POST['emp_dep']
		emp_status=request.POST['emp_status']
		emp_city=request.POST['emp_city']
		emp_desig=request.POST['emp_desig']
		emp_father=request.POST['emp_father']
		emp_spouse=request.POST['emp_spouse']
		emp_address=request.POST['emp_address']
		emp_dob=request.POST['emp_dob']
		emp_doj=request.POST['emp_doj']
		
		emp_ph=request.POST['emp_ph']
		emp_email=request.POST['emp_email']
		emp_pan=request.POST['emp_pan']
		emp_aadhaar=request.POST['emp_aadhaar']
		emp_img=request.POST['emp_img']
		emp_salary=float(request.POST['emp_salary'])
		emp_ot=request.POST['emp_ot']
		emp_ot_amt=float(request.POST['emp_ot_amt'])
		emp_pf=request.POST['emp_pf']
		emp_pf_amt=float(request.POST['emp_pf_amt'])
		emp_esi=request.POST['emp_esi']
		emp_esi_amt=float(request.POST['emp_esi_amt'])
		emp_p_mode=request.POST['emp_p_mode']
		emp_credit=request.POST['emp_credit']
		emp_bank=request.POST['emp_bank']
		emp_ifsc=request.POST['emp_ifsc']
		emp_gen=request.POST['emp_gen']
		
		user_type=User.username
		stamp_date=datetime.now()

		uname=emp_name
		pss=request.POST['passname']
		new_item=emp_setup(emp_id=emp_id,emp_code=emp_code,emp_name=emp_name,emp_dep=emp_dep,emp_status=emp_status,emp_city=emp_city,emp_desig=emp_desig,emp_father=emp_father,emp_spouse=emp_spouse,emp_address=emp_address,emp_dob=emp_dob,emp_doj=emp_doj,emp_ph=emp_ph,emp_email=emp_email,emp_pan=emp_pan,emp_aadhaar=emp_aadhaar,emp_img=emp_img,emp_salary=emp_salary,emp_ot=emp_ot,emp_ot_amt=emp_ot_amt,emp_pf=emp_pf,emp_pf_amt=emp_pf_amt,emp_esi=emp_esi,emp_esi_amt=emp_esi_amt,emp_p_mode=emp_p_mode,emp_credit=emp_credit,emp_bank=emp_bank,emp_ifsc=emp_ifsc,emp_gen=emp_gen,user_type=user_type,stamp_date=stamp_date)
		new_item.save()
		
		#create the users
		myuser =User.objects.create_user(uname,emp_email,pss)
		myuser.save()
		user_id = myuser.id
		new_group, created = Group.objects.get_or_create(name=emp_dep)
		new_group.user_set.add(user_id)

		

		return HttpResponseRedirect(reverse('emp_setup1'))
	elif request.method=='GET':
		return render(request,'add_emp_new.html')
	else:
		return HttpResponse('Exception Occured')

def remove_emps(request, emp_id=0):
	if emp_id:
		try:
			emp_to_be_removed = emp_setup.objects.get(emp_id=emp_id)
			emp_to_be_removed.delete()
			data=emp_setup.objects.all().order_by('emp_id')
			context={
				'emp':data,
		
			}
			return render(request, 'emp_setup.html', context=context)
		except:
			return HttpResponse('Enter id')
	data=emp_setup.objects.all()
	context={
		"emp":data
	}
	return render(request, 'removeemp.html', context)

def filter_emp_new(request):	
	if request.method =="POST":
		first_name=request.POST['emp_name']
		emps=emp_setup.objects.all()
		if first_name:
			emps=emps.filter(emp_name__icontains=first_name)
			#emps=emps.filter(Q(first_name__icontains = first_name)|Q(last_name__icontains=last_name))
			context={
				'emp':emps
			}
		else:
			data=emp_setup.objects.all().order_by('emp_id')
			Tot_Cust = emp_setup.objects.all().count()
			Regular_Cust = emp_setup.objects.filter(emp_status='Working').count()
			Contract_Cust = emp_setup.objects.filter(emp_status='Retired').count()
			NEW_Cust = emp_setup.objects.filter(emp_credit='Yes').count()
			context={
				'emp':data,
				'Tot_count_cus':Tot_Cust,
				'Reg_cus':Regular_Cust,
				'Con_cus':Contract_Cust,
				'new_cus':NEW_Cust
					}			
			return redirect('/emp_setup1')
		return render(request, 'emp_setup.html', context)
		
	elif request.method=='GET':
		return render(request, 'emp_setup.html', context)
	else:
		return HttpResponse('An Exception')

def edit_emp_new(request, emp_id=0):
	if emp_id:
		emps = emp_setup.objects.filter(emp_id =emp_id)
		context={
			'emp':emps
			}
		return render(request, 'filter_emp_new.html', context)

def update_emp_new(request, emp_id=0):
	if emp_id:
		if request.method =="POST":
			#emp_to_be_removed = emp_setup.objects.get(emp_id=emp_id)
			#emp_to_be_removed.delete()
			t = emp_setup.objects.get(emp_id=emp_id)
			t.emp_code=request.POST['emp_code']
			t.emp_name=request.POST['emp_name']
			t.emp_dep=request.POST['emp_dep']
			t.emp_status=request.POST['emp_status']
			t.emp_city=request.POST['emp_city']
			t.emp_desig=request.POST['emp_desig']
			t.emp_father=request.POST['emp_father']
			t.emp_spouse=request.POST['emp_spouse']
			t.emp_address=request.POST['emp_address']
			t.emp_ph=request.POST['emp_ph']
			t.emp_email=request.POST['emp_email']
			t.emp_pan=request.POST['emp_pan']
			t.emp_aadhaar=request.POST['emp_aadhaar']
			t.emp_salary=request.POST['emp_salary']
			t.emp_ot=request.POST['emp_ot']
			t.emp_ot_amt=request.POST['emp_ot_amt']
			t.emp_pf=request.POST['emp_pf']
			t.emp_pf_amt=request.POST['emp_pf_amt']
			t.emp_esi=request.POST['emp_esi']
			t.emp_esi_amt=request.POST['emp_esi_amt']
			t.emp_p_mode=request.POST['emp_p_mode']
			t.emp_credit=request.POST['emp_credit']
			t.emp_bank=request.POST['emp_bank']
			t.emp_ifsc=request.POST['emp_ifsc']
			t.emp_gen=request.POST['emp_gen']			
			t.save()
			return HttpResponseRedirect(reverse('emp_setup1'))
		elif request.method=='GET':
			return render(request,'filter_emp_new.html')
		else:
			return HttpResponse('Exception Occured')

			
def att_setup(request): #This is the main display page of employees
	return render(request, 'attendance_setup.html', context=context)

from django import template

register = template.Library() 

@register.filter(name='has_group') 
def has_group(user, group_name):
    return user.groups.filter(name=group_name).exists() 