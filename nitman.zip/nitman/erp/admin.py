from django.contrib import admin
from .models import Person,Item_Master,emp_setup,att_setup,Page_itms

# Register your models here.
admin.site.register(Person)
admin.site.register(Item_Master)
admin.site.register(emp_setup)
admin.site.register(att_setup)
admin.site.register(Page_itms)
