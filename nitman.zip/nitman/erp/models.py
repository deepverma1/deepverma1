from django.db import models
# Create your models here.
from datetime import datetime, date


		
class Page_itms(models.Model):
	lst_items=models.IntegerField(default=0)


class Person(models.Model):
	cust_id= models.BigAutoField(primary_key=True)
	cust_code=models.CharField(max_length=10, default="")
	cust_name = models.CharField(max_length=100, default="")
	cust_address = models.CharField(max_length=100, default="")
	cust_city = models.CharField(max_length=100, default="")
	cust_pin = models.CharField(max_length=100, default="")
	cust_ph = models.CharField(max_length=11, default="")
	cust_email = models.CharField(max_length=111, default="")
	cust_Gst_No = models.CharField(max_length=100, default="")
	contact_per=models.CharField(max_length=100, default="")
	cust_Type=models.CharField(max_length=100, default="")
	opening_bal=models.FloatField(null=True, blank=True, default=None)
	bal_type=models.CharField(max_length=2, default="")
	user_type=models.CharField(max_length=150, default="")
	stamp_date=models.CharField(max_length=150, default="")
	

class Item_Master(models.Model):
	item_id= models.BigAutoField(primary_key=True)
	item_code=models.CharField(max_length=10, default="")
	item_name = models.CharField(max_length=30, default="")
	item_unit = models.CharField(max_length=10, default="")
	e_field=models.CharField(max_length=100,default="")
	item_cat = models.CharField(max_length=100, default="")
	qty_in_hand = models.IntegerField(default=0)
	qty_warning = models.IntegerField(default=0)
	sale_price=models.FloatField(default=0)
	pur_price=models.FloatField(default=0)
	e_int_f=models.FloatField(default=0)
	item_desc=models.CharField(max_length=150, default="")
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")
	
class emp_setup(models.Model):
	emp_id= models.BigAutoField(primary_key=True)
	emp_code=models.CharField(max_length=10, default="")
	emp_name = models.CharField(max_length=30, default="")
	emp_dep = models.CharField(max_length=100, default="")
	emp_status = models.CharField(max_length=100, default="")
	emp_city = models.CharField(max_length=11, default="")
	emp_desig = models.CharField(max_length=100, default="")
	emp_father=models.CharField(max_length=100, default="")
	emp_spouse=models.CharField(max_length=100, default="")
	emp_address=models.CharField(max_length=100, default="")
	emp_dob=models.DateField(auto_now_add=False,auto_now=False, blank=True)
	emp_doj=models.DateField(auto_now_add=False,auto_now=False, blank=True)
	emp_ph=models.CharField(max_length=100, default="")
	emp_email=models.CharField(max_length=100, default="")
	emp_pan=models.CharField(max_length=100, default="")
	emp_aadhaar=models.CharField(max_length=100, default="")
	emp_img=models.ImageField(upload_to='erp/images/')
	emp_salary=models.FloatField(null=True, blank=True, default=None)
	emp_ot=models.CharField(max_length=100, default="")
	emp_ot_amt=models.FloatField(null=True, blank=True, default=None)
	emp_pf=models.CharField(max_length=100, default="")
	emp_pf_amt=models.FloatField(null=True, blank=True, default=None)
	emp_esi=models.CharField(max_length=100, default="")
	emp_esi_amt=models.FloatField(null=True, blank=True, default=None)
	emp_p_mode=models.CharField(max_length=100, default="")
	emp_credit=models.CharField(max_length=100, default="")
	emp_bank=models.CharField(max_length=100, default="")
	emp_ifsc=models.CharField(max_length=100, default="")
	emp_gen=models.CharField(max_length=100, default="")
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")

	
class att_setup(models.Model):
	emp_id= models.BigAutoField(primary_key=True)
	emp_code=models.CharField(max_length=10, default="")
	emp_name = models.CharField(max_length=30, default="")
	emp_dep = models.CharField(max_length=100, default="")
	emp_desig = models.CharField(max_length=100, default="")
	emp_in_time=models.DateField(auto_now_add=False,auto_now=False, blank=True)
	emp_out_time=models.DateField(auto_now_add=False,auto_now=False, blank=True)
	emp_status=models.CharField(max_length=100, default="")#Present/Absent
	emp_location=models.CharField(max_length=100, default="")#Present/Absent
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")
