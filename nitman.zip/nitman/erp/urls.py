from django.contrib import admin
from django.urls import path, include
from  . import views  
from .views import redirect_view

urlpatterns = [
    path('home', views.index, name = 'index'),
    path("", include("django.contrib.auth.urls")),
	path('all_emp', views.all_emp, name = 'all_emp'),
	path('add_emp', views.add_emp, name = 'add_emp'),
    path('remove_emp/<int:emp_id>', views.remove_emp, name = 'remove_emp'),
    path('filter_emp', views.filter_emp, name = 'filter_emp'),
	path('edit_emp/<int:emp_id>', views.edit_emp, name = 'filter_emp'),
    path('update_emp/<int:emp_id>', views.update_emp, name = 'update_emp'),
    path('item_setup', views.item_setup, name = 'item_setup'),
    path('add_item', views.add_item, name = 'add_item'),
    path('remove_items/<int:emp_id>', views.remove_items, name = 'remove_items'),
    path('edit_items/<int:emp_id>', views.edit_items, name = 'edit_items'),
    path('update_items/<int:emp_id>', views.update_items, name = 'update_items'),
    path('filter_item', views.filter_item, name = 'filter_item'),
    path('emp_setup1', views.emp_setup1, name = 'emp_setup1'),
    path('redirect/', redirect_view),
    path('add_emp_new', views.add_emp_new, name = 'add_emp_new'),    
    path('remove_emps/<int:emp_id>', views.remove_emps, name = 'remove_emps'),
    path('filter_emp_new', views.filter_emp_new, name = 'filter_emp_new'),
    path('edit_emp_new/<int:emp_id>', views.edit_emp_new, name = 'edit_emp_new'),
    path('update_emp_new/<int:emp_id>', views.update_emp_new, name = 'update_emp_new'),
    path('att_setup', views.att_setup, name = 'att_setup'),

]
