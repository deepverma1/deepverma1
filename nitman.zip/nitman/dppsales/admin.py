from django.contrib import admin
from .models import sale_Order,customer_Ledger,stock_Register,cash_vouchor_new,unit_master,voucherNo_db,bill_items,shipping_info,complaint_box,pur_Order
# Register your models here.
admin.site.register(sale_Order)
admin.site.register(customer_Ledger)
admin.site.register(stock_Register)
admin.site.register(cash_vouchor_new)
admin.site.register(unit_master)
admin.site.register(voucherNo_db)
admin.site.register(bill_items)
admin.site.register(shipping_info)
admin.site.register(complaint_box)
admin.site.register(pur_Order)