from django.apps import AppConfig


class DppsalesConfig(AppConfig):
    name = 'dppsales'
