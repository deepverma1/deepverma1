from dataclasses import dataclass
from datetime import date,datetime
import json
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render
from cus_leads.models import inquiry_setup
from .models import sale_Order,customer_Ledger, stock_Register,cash_vouchor_new,unit_master,voucherNo_db,bill_items,shipping_info,complaint_box,pur_Order
from erp.models import Person,Item_Master
from django.shortcuts import render, HttpResponse, redirect
from django.db.models import Max,Sum
from django.core.mail import send_mail
from django.contrib import messages
# Create your views here.

def index(request):
	
	return render(request, 'salesorder.html')

def add_new_sale_order(request):
	C_name=Person.objects.all()		# person names will be shown in search button
	p_name=Item_Master.objects.all()# products will be shown
	res = voucherNo_db.objects.filter(voucherType="Sale Bill").aggregate(max_id=Max('voucherNo')) # fetch the latest bill
	p=res.get('max_id')
	if p is None:
		p=0
	s_bill_no=int(p)+1
	
	context={
		'c_name1':C_name,
		'p_name':p_name,
			}
	if request.method=="POST":
		c_name=Person.objects.filter(cust_name=request.POST['myBrowser'])
		complaintBox=complaint_box.objects.filter(company_name=request.POST['myBrowser'])
		shippings=shipping_info.objects.filter(party_name=request.POST['myBrowser'])
		context={
		'c_name':C_name,
		'c_name_filter':c_name,
		'p_name':p_name,
		'saleBill':s_bill_no,
		'complaintBox':complaintBox,
		'shippings':shippings
		}
		return render(request, 'new_sale_order.html', context)
	elif request.method=='GET':
		return render(request, 'new_sale_order.html',context)
	else:
		return HttpResponse('Exception Occured')

def purchase_bill(request):
	C_name=Person.objects.all()		# person names will be shown in search button
	p_name=Item_Master.objects.all()# products will be shown
	
	context={
		'c_name1':C_name,
		'p_name':p_name,
			}
	if request.method=="POST":
		parties_name=Person.objects.filter(cust_name=request.POST['myBrowser'])
		complaintBox=complaint_box.objects.filter(company_name=request.POST['myBrowser'])
		shippings=shipping_info.objects.filter(party_name=request.POST['myBrowser'])
		context={
		#'c_name':C_name,
		'c_name_filter':parties_name,
		'p_name':p_name,
		'complaintBox':complaintBox,
		'shippings':shippings
		}
		return render(request, 'purchaseBill.html', context)
	elif request.method=='GET':
		return render(request, 'purchaseBill.html',context)
	else:
		return HttpResponse('Exception Occured')


def add_new_sale(request):				#New Sale Bill Add Karna
	if request.method =="POST":
		post_id = json.loads(request.POST['js_data'])
		print(post_id)
		jsonLength=len(post_id)
		if request.POST['e_date']=='':
			return HttpResponse('Select Date First')
		else:
			#for i in range(0,jsonLength):
			res = sale_Order.objects.filter().aggregate(max_id=Max('s_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=p+1
			s_Bill_No=request.POST['bill_no']
			s_date=request.POST['e_date']
			cust_name=request.POST['cust_name']
			party_name=request.POST['c_name']
			supply_place=request.POST['e_supply']
			cust_city=request.POST['e_city']
			cust_address=request.POST['e_address']
			cust_mobile=request.POST['e_mobile']
			cust_Gst=request.POST['e_gst1']
			cust_state=request.POST['e_state']
			cust_transport_mode=request.POST['e_trans1']
			transport_pay_type=request.POST['e_trans2']
			item_tax_amt=float(request.POST['total_tax'])
			item_grand_total=float(request.POST['g_total'])-float(request.POST['total_tax'])
			item_after_tax_total=float(request.POST['g_total'])
			sale_order_status="New Order"
			new_emp=sale_Order(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=supply_place,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,cust_state=cust_state,cust_transport_mode=cust_transport_mode,item_tax_amt=item_tax_amt,item_grand_total=item_grand_total,item_after_tax_total=item_after_tax_total,sale_order_status=sale_order_status,transport_pay_type=transport_pay_type)
			new_emp.save()
			print(new_emp)
		
			#for i in range(0,jsonLength):
			
			for i in range(0,jsonLength):
				res = stock_Register.objects.filter().aggregate(max_id=Max('s_id'))
				p=res.get('max_id')
				if p is None:
					p=0
				c_id=p+1
				s_Bill_No=request.POST['bill_no']
				s_date=request.POST['e_date']
				cust_name=request.POST['cust_name']
				party_name=request.POST['c_name']
				supply_place=request.POST['e_supply']
				cust_city=request.POST['e_city']
				cust_address=request.POST['e_address']
				cust_mobile=request.POST['e_mobile']
				cust_Gst=request.POST['e_gst1']
				cust_state=request.POST['e_state']
				cust_transport_mode=request.POST['e_trans2']

				item_name=post_id[i]['item']
				item_desc=post_id[i]['description']
				item_hsn=post_id[i]['hsn']
				item_size=post_id[i]['size']
				item_thick=post_id[i]['thickness']
				item_color=post_id[i]['color']
				item_qty=post_id[i]['qty']
				item_price=post_id[i]['price']
				new_stock=stock_Register(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=supply_place,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,cust_state=cust_state,cust_transport_mode=cust_transport_mode,item_name=item_name,item_desc=item_desc,item_hsn=item_hsn,item_size=item_size,item_thick=item_thick,item_color=item_color,item_qty=item_qty,item_price=item_price)
				new_stock.save()
			for i in range(0,jsonLength):
				res = bill_items.objects.filter().aggregate(max_id=Max('s_id'))
				p=res.get('max_id')
				if p is None:
					p=0
				c_id=p+1
				s_Bill_No=request.POST['bill_no']
				s_date=request.POST['e_date']
				cust_name=request.POST['cust_name']
				party_name=request.POST['c_name']
				item_name=post_id[i]['item']
				item_desc=post_id[i]['description']
				item_hsn=post_id[i]['hsn']
				item_size=post_id[i]['size']
				item_thick=post_id[i]['thickness']
				item_color=post_id[i]['color']
				item_qty=post_id[i]['qty']
				item_price=post_id[i]['price']
				item_tax=float(post_id[i]['taxable'])
				item_gst=float(post_id[i]['gst'])
				item_amt=float(post_id[i]['amount'])

				new_stock=bill_items(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,item_name=item_name,item_desc=item_desc,item_hsn=item_hsn,item_size=item_size,item_thick=item_thick,item_color=item_color,item_qty=item_qty,item_price=item_price,item_tax=item_tax,item_gst=item_gst,item_amt=item_amt)
				new_stock.save()

			res = customer_Ledger.objects.filter().aggregate(max_id=Max('s_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=p+1
			s_Bill_No=request.POST['bill_no']
			s_date=request.POST['e_date']
			cust_name=request.POST['cust_name']
			party_name=request.POST['c_name']
			supply_place=request.POST['e_supply']
			cust_city=request.POST['e_city']
			cust_address=request.POST['e_address']
			cust_mobile=request.POST['e_mobile']
			cust_Gst=float(post_id[i]['gst'])
			cust_state=request.POST['e_state']
			item_grand_total=float(request.POST['g_total'])-float(request.POST['total_tax'])
			item_after_tax_total=float(request.POST['g_total'])
			transaction_type="Sale Bill"
			a_type="Dr"
			new_led=customer_Ledger(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=supply_place,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,cust_state=cust_state,item_grand_total=item_grand_total,item_after_tax_total=item_after_tax_total,bal_type=a_type,transaction_type=transaction_type)
			new_led.save()
			res = voucherNo_db.objects.filter(voucherType="Sale Bill").aggregate(max_id=Max('voucherNo'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=int(p)+1
			voucherNo=request.POST['bill_no']
			voucherType="Sale Bill"
			new_stock=voucherNo_db(voucherId=c_id,voucherNo=voucherNo,voucherType=voucherType)
			new_stock.save()
			# shipping info of order
			res = shipping_info.objects.filter().aggregate(max_id=Max('s_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=p+1
			s_Bill_No=request.POST['bill_no']
			s_date=request.POST['e_date']
			cust_name=request.POST['cust_name']
			party_name=request.POST['c_name']
			ship_name=request.POST['e_trans1']

			ship_address=request.POST['e_address1']
			ship_city=request.POST['e_city']
			ship_code=request.POST['e_pin']
			ship_ph=request.POST['e_mobile']
			ship_gst=request.POST['e_gst1']
			new_emp=shipping_info(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,ship_name=ship_name,ship_address=ship_address,ship_city=ship_city,ship_code=ship_code,ship_ph=ship_ph,ship_gst=ship_gst)
			new_emp.save()
			return HttpResponse('Saved')

def cust_ledger(request):
	C_name=Person.objects.all()
	
	context={
		'd1':C_name,		
			}
	if request.method=="POST":
		C_name=Person.objects.all()
		cust_name=request.POST['myBrowser']
		s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
		e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
		#c_name=customer_Ledger.objects.filter(cust_name=cust_name).filter(s_date>=s_date).filter(s_date<=e_date)
		c_name=customer_Ledger.objects.filter(s_date__range=[s_date, e_date]).filter(party_name=cust_name)
		context={
		'd':c_name,
		'd1':C_name
			}
		return render(request, 'cust_ledger.html', context)
	elif request.method=='GET':
		return render(request, 'cust_ledger.html',context)
	else:
		return HttpResponse('Exception Occured')

def cash_voucher(request):
	C_name=Person.objects.all()
	context={
		'd':C_name,
			}
	if request.method=="POST":
		c_name=Person.objects.filter(cust_name=request.POST['account_name'])
		context={
		'd':C_name,
		'd1':c_name
			}
		return render(request, 'cash_voucher.html', context)
	elif request.method=='GET':
		return render(request, 'cash_voucher.html',context)
	else:
		return HttpResponse('Exception Occured')

def cash_voucher_save(request):
	if request.method=="POST":
		res = cash_vouchor_new.objects.filter().aggregate(max_id=Max('s_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		c_id=p+1
		s_date=request.POST['e_date']
		cust_name=request.POST['C_Name']
		party_name=request.POST['C_Name']
		t_type=request.POST['t_type']
		against_bill=request.POST['against_bill']
		total_amt=float(request.POST['t_amt'])
		bal_type=request.POST['e_type']
		transaction_type="Cash Voucher"

		new_stock=cash_vouchor_new(s_id=c_id,s_date=s_date,cust_name=cust_name,party_name=party_name,t_type=t_type,against_bill=against_bill,total_amt=total_amt,bal_type=bal_type,transaction_type=transaction_type)
		new_stock.save()

		res = customer_Ledger.objects.filter().aggregate(max_id=Max('s_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		c_id=p+1
		s_date=request.POST['e_date']
		cust_name=request.POST['C_Name']
		party_name=request.POST['C_Name']
		t_type=request.POST['t_type']
		against_bill=request.POST['against_bill']
		total_amt=float(request.POST['t_amt'])
		bal_type=request.POST['e_type']
		transaction_type="Cash Voucher"
		new_led=customer_Ledger(s_id=c_id,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=t_type,cust_city=against_bill,item_grand_total=total_amt,item_after_tax_total=total_amt,bal_type=bal_type,transaction_type=transaction_type)
		new_led.save()

		return render(request, 'cash_voucher.html')
	elif request.method=='GET':
		return render(request, 'cash_voucher.html')
	else:
		return HttpResponse('Exception Occured')


def sale_order_display(request):
	C_name=Person.objects.all()
	context={
		'd1':C_name,		
			}
	if request.method=="POST":
		C_name=sale_Order.objects.all()
		if request.POST['s_date'] or request.POST['e_date'] is None:
			s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
			e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
			c_name=sale_Order.objects.filter(s_date__range=[s_date, e_date])
			context={
			'd':c_name,
			'd1':C_name
				}
			return render(request, 'sale_order_display.html', context)
		else:
			return HttpResponse('Please Select Date First...')
	elif request.method=='GET':
		return render(request, 'sale_order_display.html',context)
	else:
		return HttpResponse('Exception Occured')

from django.db.models import Count
def stockReports(request):
	itemNames=Item_Master.objects.all()
	context={
		'd1':itemNames,		
			}
	if request.method=="POST":
		
		if request.POST['s_date'] or request.POST['e_date'] is None:
			s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
			e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
			itemNames=Item_Master.objects.all()
			sale_stockCalulations=stock_Register.objects.values('item_name','item_desc').filter(s_date__range=[s_date, e_date]).annotate(total_sale=Sum('item_pur')-Sum('item_qty'))
			context={
			'd':itemNames,
			'stock':sale_stockCalulations
				}
			return render(request, 'stock_report.html', context)
		else:
			return HttpResponse('Please Select Date First...')
	elif request.method=='GET':
		return render(request, 'stock_report.html',context)
	else:
		return HttpResponse('Exception Occured')

def production_reports(request):
	C_name=Person.objects.all()
	context={
		'd1':C_name,		
			}
	if request.method=="POST":
		C_name=sale_Order.objects.all()
		if request.POST['s_date'] or request.POST['e_date'] is None:
			s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
			e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
			c_name=sale_Order.objects.filter(s_date__range=[s_date, e_date]).filter(sale_order_status='Approved')
			item_name=bill_items.objects.filter(s_date__range=[s_date, e_date])
			context={
			'd':c_name,
			'd1':C_name,
			'itms':item_name
				}
			return render(request, 'production_report.html', context)
		else:
			return HttpResponse('Please Select Date First...')
	elif request.method=='GET':
		return render(request, 'production_report.html',context)
	else:
		return HttpResponse('Exception Occured')

def add_new_sale_update(request):
	if request.method =="POST":
		t = sale_Order.objects.filter(s_Bill_No=request.POST['lname'])
		if t is not None:
			for i in t:
				i.sale_order_status="Forwarded"
				i.save()
			email_me("atcludhiana2010@gmail.com",'Sale Order Approval','Please Approve the Sale Bill No'+request.POST['lname'])
			context={'msg':'Successfully Forwarded'
			}
		
		return render(request,'sale_order_display.html')
	elif request.method=='GET':
		return render(request,'sale_order_display.html')
	else:
		return HttpResponse('Exception Occured')


def formation_update(request):
	if request.method =="POST":
		t = sale_Order.objects.filter(s_id=request.POST['lname']).first()
		if t is not None:
			t.formation_status=request.POST['formation_status']
			t.formation_remarks=request.POST['formation']
			t.save()
			email_me("atcludhiana2010@gmail.com",'Order Updated','Your Order No. '+request.POST['lname'] + 'is in process')
			context={'msg':'Successfully Forwarded'
			}
		
		return render(request,'production_report.html')
	elif request.method=='GET':
		return render(request,'production_report.html')
	else:
		return HttpResponse('Exception Occured')

		

def formation_completed(request):
	if request.method =="POST":
		t = sale_Order.objects.filter(s_id=request.POST['lname1']).first()
		if t is not None:
			t.formation_status=request.POST['formation_status1']
			#t.formation_remarks=request.POST['formation1']
			t.item_qty=request.POST['qty11']
			t.save()
			email_me("atcludhiana2010@gmail.com",'Order Updated','Your Order No. '+request.POST['lname1'] + 'is in process')
			context={'msg':'Successfully Forwarded'
			}
		return render(request,'production_report.html')
	elif request.method=='GET':
		return render(request,'production_report.html')
	else:
		return HttpResponse('Exception Occured')

def approve_sale_order(request):
	if request.method =="POST":
		t = sale_Order.objects.filter(s_Bill_No=request.POST['lname'])
		if t is not None:
			for i in t:
				i.sale_order_status=request.POST['sale_order_status']
				i.remarks_cust=request.POST['formation']
				i.save()
			email_me("atcludhiana2010@gmail.com",'Sale Order Approval','Please Approve the Sale Bill No'+request.POST['lname'])
			context={'msg':'Successfully Updated'
			}
		
		return render(request,'check_customer_status.html')
	elif request.method=='GET':
		return render(request,'check_customer_status.html')
	else:
		return HttpResponse('Exception Occured')


def email_me(tomail,esubject,emailbody): # Sending Automatically email declaration module
	toemail=tomail
	esub=esubject
	ebody=emailbody
	
	send_mail(
		esub,
		ebody,
		'from@example.com',
		[toemail],
		fail_silently=False,
		)

def party_status_check(request):
	C_name=Person.objects.all()
	context={
		'd1':C_name,		
			}
	if request.method=="POST":
		C_name=sale_Order.objects.all()
		if request.POST['s_date'] or request.POST['e_date'] is None:
			s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
			e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
			c_name=sale_Order.objects.filter(s_date__range=[s_date, e_date],sale_order_status="Forwarded")
			context={
			'd':c_name,
			'd1':C_name
				}
			return render(request, 'check_customer_status.html', context)
		else:
			return HttpResponse('Please select Date First')
	elif request.method=='GET':
		return render(request, 'check_customer_status.html',context)
	else:
		return HttpResponse('Exception Occured')


def party_status(request,emp_id=""):
	c_name=Person.objects.filter(cust_name=emp_id)
	sale_data=sale_Order.objects.filter(~Q(sale_order_status="New Order")).filter(cust_name=emp_id)
	dr_amount=customer_Ledger.objects.filter(cust_name=emp_id,bal_type="Dr").aggregate(Sum('item_grand_total'))['item_grand_total__sum']
	cr_amount=customer_Ledger.objects.filter(cust_name=emp_id,bal_type="Cr").aggregate(Sum('item_grand_total'))['item_grand_total__sum']
	if dr_amount is None:
		dr_amount=0
	elif cr_amount is None:
		cr_amount=0
	bal=dr_amount-cr_amount
	print(cr_amount)
	context={
		'd1':c_name,
		'd':sale_data,		
		'balance':bal,
		'sale_amt':dr_amount,
		'rec_amt':cr_amount,	
			}
	if request.method=="POST":
		#C_name=sale_Order.objects.all()
		#if request.POST['s_date'] or request.POST['e_date'] is None:
		#	s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
		#	e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
		#	c_name=sale_Order.objects.filter(s_date__range=[s_date, e_date],sale_order_status="Forwarded")
		#	context={
		#	'd':c_name,
		#	'get_name':C_name
		#		}
		#	return render(request, 'party_sts.html', context)
		#else:
		return HttpResponse('Please select Date First')
	elif request.method=='GET':
		return render(request, 'party_sts.html',context)
	else:
		return HttpResponse('Exception Occured')

def complaint_master(request):
	data1=complaint_box.objects.all().order_by('c_id')
	context={
		'emp1':data1,
			}
	return render(request, 'complaint_box.html', context=context)

def add_complaint(request):
	companyNames = complaint_box.objects.all()
	context={
		'companyNames':companyNames
			}
	if request.method =="POST":
		res = complaint_box.objects.filter().aggregate(max_id=Max('c_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		c_id=int(p)+1
		company_name=request.POST['company_name']
		complaint_desc=request.POST['complaintDesc']
		
		new_emp=complaint_box(c_id=c_id,company_name=company_name,complaint_desc=complaint_desc)
		new_emp.save()
		
		data1=complaint_box.objects.all().order_by('c_id')
		context={
		'emp1':data1,
			}
		return render(request, 'complaint_box.html', context=context)
	elif request.method=='GET':
		return render(request,'add_complaint.html',context)
	else:
		return HttpResponse('Exception Occured')
	


def unit_master_form(request):
	data=unit_master.objects.all().order_by('u_id')
	context={
		'emp':data,
			}
	return render(request, 'unit_master1.html', context=context)

def get_item_details(request):
	if request.method == 'GET':
		post_id = request.GET['post_id']
		print(post_id)
		data=Item_Master.objects.filter(item_name=post_id)
		return JsonResponse({"data":list(data.values())})
	
def get_jsonData1(request):
	if request.method == 'GET':
		post_id = json.loads(request.GET['post_id'])
		jsonLength=len(post_id)
		for i in range(0,jsonLength):
			print(post_id[i]['description'])
		
	return HttpResponse({"data":list(post_id[0]['amount'])})


def add_new_unit(request):
	if request.method =="POST":
		res = unit_master.objects.filter().aggregate(max_id=Max('u_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		c_id=p+1
		u_name=request.POST['e_name']
		u_symbol=request.POST['C_Name']
		u_convert=request.POST['ph_no']
		new_emp=unit_master(u_id=c_id,u_name=u_name,u_symbol=u_symbol,u_convert=u_convert)
		new_emp.save()
		data=unit_master.objects.all().order_by('u_id')
		context={
		'emp':data,
			}
		#messages.info(request, 'Your password has been changed successfully!')
		#return HttpResponseRedirect(self.get_success_url())
		#return render_to_response('add_unit', message='Save complete')
		return render(request, 'unit_master1.html', context=context)
	elif request.method=='GET':
		return render(request,'add_unit.html')
	else:
		return HttpResponse('Exception Occured')
	
	
def remove_unit(request, emp_id=0):
	if emp_id:
		
		try:
			emp_to_be_removed = unit_master.objects.get(u_id=emp_id)
			emp_to_be_removed.delete()
			data=unit_master.objects.all().order_by('u_id')
			context={
			'emp':data,
				}
			return redirect('/unit_master_form')
		except:
			return HttpResponse('Enter id')
	return render(request, 'unit_master_form.html', context)
	
def edit_unit_master(request, emp_id=0):
	if emp_id:
		emps = unit_master.objects.filter(u_id =emp_id)
		context={
			'emp':emps
			}
		return render(request, 'edit_unit.html', context)

def update_complaint(request, emp_id=0):
	if emp_id:
		
		emps1 = complaint_box.objects.filter(c_id =emp_id)
		context={
			'emp1':emps1
			}
		return render(request, 'edit_complaint.html', context)

def update_unit(request, emp_id=0):
	if emp_id:
		if request.method =="POST":
			t = unit_master.objects.get(u_id=emp_id)
			if t is not None:
				t.u_name=request.POST['e_name']
				t.u_symbol=request.POST['C_Name']
				t.u_convert=request.POST['ph_no']
				t.save()
				data=unit_master.objects.all().order_by('u_id')
				context={
				'emp':data,
					}
				return redirect('/unit_master_form')
				#return render(request, 'unit_master1.html', context=context)
		elif request.method=='GET':
			return render(request,'filteremp.html')
		else:
			return HttpResponse('Exception Occured')	

def update_complaint_Save(request, emp_id=0):
	if emp_id:
		if request.method =="POST":
			t = complaint_box.objects.get(c_id=emp_id)
			if t is not None:
				t.company_name=request.POST['company_name']
				t.complaint_desc=request.POST['complaintDesc']
				t.save()
				
				data1=complaint_box.objects.all().order_by('c_id')
				context={
				'emp1':data1,
				}
			return render(request, 'complaint_box.html', context=context)
		elif request.method=='GET':
			return render(request,'complaint_box.html')
		else:
			return HttpResponse('Exception Occured')	

def remove_complaint(request, emp_id=0):
	if emp_id:
		try:
			emp_to_be_removed = complaint_box.objects.get(c_id=emp_id)
			emp_to_be_removed.delete()
			data1=complaint_box.objects.all().order_by('c_id')
			context={
				'emp1':data1,
				}
			return render(request, 'complaint_box.html', context=context)
		except:
			return HttpResponse('Enter id')
	return render(request, 'complaint_box.html', context)



def add_new_pur(request):				#New Sale Bill Add Karna
	if request.method =="POST":
		post_id = json.loads(request.POST['js_data'])
		print(post_id)
		jsonLength=len(post_id)
		if request.POST['e_date']=='':
			return HttpResponse('Select Date First')
		else:
			res = pur_Order.objects.filter().aggregate(max_id=Max('s_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=p+1
			s_Bill_No=request.POST['bill_no']
			s_date=request.POST['e_date']
			cust_name=request.POST['cust_name']
			party_name=request.POST['c_name']
			supply_place=request.POST['e_supply']
			cust_city=request.POST['e_city']
			cust_address=request.POST['e_address']
			cust_mobile=request.POST['e_mobile']
			cust_Gst=request.POST['e_gst']
			#cust_state=request.POST['e_state']
			
			item_tax_amt=float(request.POST['total_tax'])
			item_grand_total=float(request.POST['g_total'])-float(request.POST['total_tax'])
			item_after_tax_total=float(request.POST['g_total'])
			
			new_emp=pur_Order(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=supply_place,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,item_tax_amt=item_tax_amt,item_grand_total=item_grand_total,item_after_tax_total=item_after_tax_total)
			new_emp.save()
			
			for i in range(0,jsonLength):
				res = stock_Register.objects.filter().aggregate(max_id=Max('s_id'))
				p=res.get('max_id')
				if p is None:
					p=0
				c_id=p+1
				s_Bill_No=request.POST['bill_no']
				s_date=request.POST['e_date']
				cust_name=request.POST['cust_name']
				party_name=request.POST['c_name']
				supply_place=request.POST['e_supply']
				cust_city=request.POST['e_city']
				cust_address=request.POST['e_address']
				cust_mobile=request.POST['e_mobile']
				cust_Gst=request.POST['e_gst']
				
				

				item_name=post_id[i]['item']
				item_desc=post_id[i]['description']
				item_hsn=post_id[i]['hsn']
				item_size=post_id[i]['size']
				item_thick=post_id[i]['thickness']
				item_color=post_id[i]['color']
				item_pur=post_id[i]['qty']
				item_price=post_id[i]['price']
				new_stock=stock_Register(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=supply_place,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,item_name=item_name,item_desc=item_desc,item_hsn=item_hsn,item_size=item_size,item_thick=item_thick,item_color=item_color,item_pur=item_pur,item_price=item_price)
				new_stock.save()

			for i in range(0,jsonLength):
				res = bill_items.objects.filter().aggregate(max_id=Max('s_id'))
				p=res.get('max_id')
				if p is None:
					p=0
				c_id=p+1
				s_Bill_No=request.POST['bill_no']
				s_date=request.POST['e_date']
				cust_name=request.POST['cust_name']
				party_name=request.POST['c_name']
				item_name=post_id[i]['item']
				item_desc=post_id[i]['description']
				item_hsn=post_id[i]['hsn']
				item_size=post_id[i]['size']
				item_thick=post_id[i]['thickness']
				item_color=post_id[i]['color']
				item_qty=post_id[i]['qty']
				item_price=post_id[i]['price']
				item_tax=float(post_id[i]['taxable'])
				item_gst=float(post_id[i]['gst'])
				item_amt=float(post_id[i]['amount'])
				bill_type="Purchase"
				new_stock=bill_items(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,item_name=item_name,item_desc=item_desc,item_hsn=item_hsn,item_size=item_size,item_thick=item_thick,item_color=item_color,item_qty=item_qty,item_price=item_price,item_tax=item_tax,item_gst=item_gst,item_amt=item_amt,bill_type=bill_type)
				new_stock.save()

			res = customer_Ledger.objects.filter().aggregate(max_id=Max('s_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=p+1
			s_Bill_No=request.POST['bill_no']
			s_date=request.POST['e_date']
			cust_name=request.POST['cust_name']
			party_name=request.POST['c_name']
			supply_place=request.POST['e_supply']
			cust_city=request.POST['e_city']
			cust_address=request.POST['e_address']
			cust_mobile=request.POST['e_mobile']
			cust_Gst=float(post_id[i]['gst'])
			
			item_grand_total=float(request.POST['g_total'])-float(request.POST['total_tax'])
			item_after_tax_total=float(request.POST['g_total'])
			transaction_type="Purchase Bill"
			a_type="Cr"
			new_led=customer_Ledger(s_id=c_id,s_Bill_No=s_Bill_No,s_date=s_date,cust_name=cust_name,party_name=party_name,supply_place=supply_place,cust_city=cust_city,cust_address=cust_address,cust_mobile=cust_mobile,cust_Gst=cust_Gst,item_grand_total=item_grand_total,item_after_tax_total=item_after_tax_total,bal_type=a_type,transaction_type=transaction_type)
			new_led.save()
			res = voucherNo_db.objects.filter(voucherType="Purchase Bill").aggregate(max_id=Max('voucherNo'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=int(p)+1
			voucherNo=request.POST['bill_no']
			voucherType="Purchase Bill"
			new_stock=voucherNo_db(voucherId=c_id,voucherNo=voucherNo,voucherType=voucherType)
			new_stock.save()
			return HttpResponse('Saved')

def purchase_bill_report(request):
	C_name=Person.objects.all()
	context={
		'd1':C_name,		
			}
	if request.method=="POST":
		C_name=sale_Order.objects.all()

		if request.POST['s_date'] or request.POST['e_date'] is None:
			s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
			e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()

			c_name=pur_Order.objects.filter(s_date__range=[s_date, e_date])

			context={
			'd':c_name,
			'd1':C_name
				}
			return render(request, 'purchaseBillReports.html', context)
		else:
			return HttpResponse('Please Select Date First...')
	elif request.method=='GET':
		return render(request, 'purchaseBillReports.html',context)
	else:
		return HttpResponse('Exception Occured')