
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

d1={'name':['a','b','c'],'rollno':[1,2,3],'marks':[10,20,30]}
d1=pd.DataFrame(d1,index=[1,2,3])
print(d1)



df = pd.DataFrame(d1)
fig, ax =plt.subplots(figsize=(12,4))
ax.axis('tight')
ax.axis('off')
the_table = ax.table(cellText=df.values,colLabels=df.columns,loc='center')


pp = PdfPages("foo.pdf")
pp.savefig(fig, bbox_inches='tight')
pp.close()