from django.contrib import admin
from .models import inquiry_setup,IndiaMart_leads,mailsdb1,sent_mails,call_status_update,manualLeadsRequirement
# Register your models here.
admin.site.register(inquiry_setup)
admin.site.register(IndiaMart_leads)
admin.site.register(mailsdb1)
admin.site.register(sent_mails)
admin.site.register(call_status_update)
admin.site.register(manualLeadsRequirement)