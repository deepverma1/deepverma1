import django
from numpy import require
import pandas as pd
import json
from django.http import JsonResponse
from tabnanny import check
from django.utils.dateparse import parse_date
from multiprocessing import context
from ssl import AlertDescription
from django.shortcuts import render, HttpResponse, redirect
from django.core.mail import send_mail
import pywhatkit
#from requests_toolbelt import user_agent
from .models import inquiry_setup,IndiaMart_leads,mailsdb1,call_status_update,sent_mails,manualLeadsRequirement
from erp.models import Person,emp_setup,Page_itms,Item_Master
from django.db.models import Max
from django.http import HttpResponseRedirect
from django.urls import reverse
from datetime import datetime
from django.core.paginator import Paginator
import requests
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User


def email_me(tomail,esubject,emailbody): # Sending Automatically email declaration module
	toemail=tomail
	esub=esubject
	ebody=emailbody
	
	send_mail(
		esub,
		ebody,
		'from@example.com',
		toemail,
		fail_silently=True,
		)


def c_status(request,emp_id=0):
	if emp_id:
		emps = inquiry_setup.objects.filter(e_id=emp_id)
		status_db1 = call_status_update.objects.filter(name=emp_id)
		
		empnames=emp_setup.objects.all().order_by('emp_id')
		p_email=inquiry_setup.objects.filter(e_id=emp_id).values('e_mail')		
		#Here we are fetching the emails from our database
		
		test = pd.read_csv('https://docs.google.com/spreadsheets/d/' + 
                   '1Anslt27W6B4N2GjTOujgLlDhSdRl8fjnVlJSqYv_5eo' +
                   '/export?gid=0&format=csv',
                   # Set first column as rownames in data frame
                   index_col=0,
                   # Parse column values to datetime
                  )
		for user in p_email:
			if user['e_mail'] is not None:
				email_val=user['e_mail']
			else:
				email_val='dds'
		sent_mails_status=sent_mails.objects.filter(email=email_val)
		print(sent_mails_status)
		ddata=test[test.email == email_val]
		df_records = ddata.to_dict('records')
		dddd=mailsdb1.objects.all()
		dddd.delete()
		model_instances = [mailsdb1(
    	name=record['name'],
    	email=record['email'],
		subject=record['subject'],
		body=record['body'],
		ddate=record['maildate'],
		) for record in df_records]
		mailsdb1.objects.bulk_create(model_instances)
		d1=mailsdb1.objects.all()
		
		context={
			'd':emps,
			'enames':empnames,
			'g1':d1,
			'status_db':status_db1,
			'sent_m':sent_mails_status
			}
		return render(request, 'c_status.html', context)
	else:
		return HttpResponse('Exception Occured')

def india_mart_status(request,emp_id=0):
	if emp_id:
		emps = IndiaMart_leads.objects.filter(UNIQUE_QUERY_ID=emp_id)
		status_db1 = call_status_update.objects.filter(name=emp_id)
		empnames=emp_setup.objects.all().order_by('emp_id')
		p_email=IndiaMart_leads.objects.filter(UNIQUE_QUERY_ID=emp_id).values('SENDER_EMAIL')
		print(p_email)
		
		
		#Here we are fetc1hing the emails from our database
		test = pd.read_csv('https://docs.google.com/spreadsheets/d/' + 
                   '1Anslt27W6B4N2GjTOujgLlDhSdRl8fjnVlJSqYv_5eo' +
                   '/export?gid=0&format=csv',
                   # Set first column as rownames in data frame
                   index_col=0,
                   # Parse column values to datetime
                  )
		for user in p_email:
			if user['SENDER_EMAIL'] is not None:
				email_val=user['SENDER_EMAIL']
			else:
				email_val='dds'
		sent_mails_status=sent_mails.objects.filter(email=email_val)
		ddata=test[test.email == email_val]
		df_records = ddata.to_dict('records')
		dddd=mailsdb1.objects.all()
		dddd.delete()
		model_instances = [mailsdb1(
    	name=record['name'],
    	email=record['email'],
		subject=record['subject'],
		body=record['body'],
		ddate=record['maildate'],
		) for record in df_records]

		mailsdb1.objects.bulk_create(model_instances)
		d1=mailsdb1.objects.all()
		
		context={
			'd':emps,
			'enames':empnames,
			'g1':d1,
			'status_db2':status_db1,
			'status_db':[status_db1,sent_mails_status],
			'sent_m':sent_mails_status
			}
		return render(request, 'india_c_status.html', context)
	else:
		return HttpResponse('Exception Occured')

def c_status_mail(request):
	if request.method =="POST":
		print("method")
		tomail1=[request.POST['cmail1'],request.POST['cc_mail'],request.POST['bcc_mail']]
		print(tomail1)
		e_mail_subject=request.POST['csub']
		print(e_mail_subject)
		e_mail_body=request.POST['textarea1']
		print(e_mail_body)

		email_me(tomail1,e_mail_subject,e_mail_body) # Email sending module
		
		#Saving Sent Mails in database
		name=request.POST['cmail1']
		email=request.POST['cmail1']
		subject=request.POST['csub']
		body=request.POST['textarea1']
		ddate=datetime.now()
		new_lead=sent_mails(name=name,email=email,subject=subject,body=body,ddate=ddate)
		new_lead.save()
		# Data Saved in database named table sentmail
		
		emps = inquiry_setup.objects.filter(e_mail2 = tomail1)
		context={
			'd':emps
			}
		return render(request, 'c_status.html',context)

	elif request.method=='GET':
		return render(request,'c_status.html')
	else:
		return HttpResponse('Exception Occured')

def redirect_view(request):
	response = redirect('/redirect-success/')
	return response

def update_leads(request):
	if request.method =="POST":
		t = inquiry_setup.objects.filter(e_id=request.POST['e_id']).first()
		if t is not None:
			if request.POST['f_ch']=="True":
				t.e_transfered=request.POST['e_asgn']+ " Due to " + request.POST['e_reason']
			else:
				t.e_assigned=request.POST['e_ass']
			t.save()
		else:
			pass
		return render(request, 'db_leads.html')
	elif request.method=="GET":
		return render(request, 'db_leads.html')
	else:
		return HttpResponse('Exception Occured')

def update_leads_indiamart(request):
	if request.method =="POST":
		t = IndiaMart_leads.objects.filter(UNIQUE_QUERY_ID=request.POST['e_id']).first()
		if t is not None:
			if request.POST['f_ch']=="True":
				t.e_transfered=request.POST['e_asgn']+ " Due to " + request.POST['e_reason']
			else:
				t.e_assigned=request.POST['e_ass']
				t.e_status="Assigned"
			t.save()
		else:
			pass
		return render(request, 'india_leads.html')
	elif request.method=="GET":
		return render(request, 'india_leads.html')
	else:
		return HttpResponse('Exception Occured')
@login_required
def add_leads_new(request):
	empnames=emp_setup.objects.all().order_by('emp_id')
	parties=Person.objects.all().order_by('cust_id')
	itemsnames=Item_Master.objects.all()
	context={
			'enames':empnames,
			'parties':parties,
			'invent':itemsnames
			}
	if request.method =="POST":
		post_id = json.loads(request.POST['json_data'])
		print(post_id)
		jsonLength=len(post_id)
		print(jsonLength)
		res = IndiaMart_leads.objects.filter().aggregate(max_id=Max('UNIQUE_QUERY_ID'))
		p=res.get('max_id')
		if p is None:
			p=0
		e_id=p+1
		product_id=e_id
		c_date=request.POST['e_date']
		client_name=request.POST['e_name']
		C_Name=request.POST['C_Name']
		ph_no=request.POST['ph_no']
		p_name=request.POST['p_name']
		c_req=request.POST['c_req']
		e_address=request.POST['e_address']
		e_city=request.POST['e_city']
		e_state=request.POST['e_state']
		e_country=request.POST['e_country']
		e_mail=request.POST['e_mail']
		e_mail2=request.POST['e_mail2']
		e_ph2=request.POST['e_ph2']
		e_type=request.POST['e_type']
		e_call_dur=request.POST['e_call_dur']
		e_status=request.POST['e_status']
		if request.POST['chk_refer'] =="True":
			Ref1=request.POST['e_withrefer']
			byemp=request.POST['e_emp_lead1']
		else:
			Ref1="Direct"
			byemp="Direct"
		e_with_reference=Ref1
		e_by_name=byemp
		e_assigned=request.POST['e_asgn']
		user_type=request.POST['username1']
		stamp_date=datetime.now()
		new_lead=IndiaMart_leads(UNIQUE_QUERY_ID=e_id,QUERY_TIME=c_date,SENDER_NAME=client_name,SENDER_COMPANY=C_Name,SENDER_MOBILE=ph_no,QUERY_PRODUCT_NAME=p_name,QUERY_MESSAGE=c_req,SENDER_ADDRESS=e_address,SENDER_CITY=e_city,SENDER_STATE=e_state,SENDER_COUNTRY_ISO=e_country,SENDER_EMAIL=e_mail,SENDER_EMAIL_ALT=e_mail2,SENDER_MOBILE_ALT=e_ph2,QUERY_TYPE=e_type,CALL_DURATION=e_call_dur,e_type=e_type,e_status=e_status,e_assigned=e_assigned,user_type=user_type,stamp_date=stamp_date,e_with_reference=e_with_reference,e_by_name=e_by_name)
		new_lead.save()	

		for i in range(0,jsonLength):
			res = manualLeadsRequirement.objects.filter().aggregate(max_id=Max('e_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			e_id=p+1
			l_no=e_id
			item_name=post_id[i]['item']
			client_require=post_id[i]['requirement']
			ret=manualLeadsRequirement(e_id=e_id,l_no=product_id,name=client_name,c_name=C_Name,product_tt=item_name,requirement=client_require)
			ret.save()
			print("saved")
		return HttpResponseRedirect(reverse('cus_leads_db'))

	elif request.method=='GET':
		return render(request,'add_leads.html',context)
	else:
		return HttpResponse('Exception Occured')

@login_required
def add_leads_indiamart(request):
	if request.method =="POST":
		c_date=datetime.strptime(request.POST['lname'], "%Y-%m-%d %H:%M:%S").date()
		t = inquiry_setup.objects.filter(e_date=c_date).first()
		if t is not None:
			t.c_date = c_date
			t.client_name=request.POST['age']
			t.C_Name=request.POST['age1']
			t.ph_no=request.POST['phno']
			t.p_name=request.POST['pname']
			t.c_req=request.POST['fname1']
			t.e_address=request.POST['add']
			t.e_city=request.POST['ccity']
			t.e_state=request.POST['cstate']
			t.e_country=request.POST['ccount']
			t.e_mail=request.POST['cemail']
			t.e_mail2=request.POST['cemail2']
			t.e_ph2=request.POST['ph12']
			t.e_type="IndiaMart"
			t.e_call_dur=request.POST['cdur']
			t.e_status="Open"
			t.e_assigned=request.POST['e_asgn']
			t.save()
			
		else:		
			res = inquiry_setup.objects.filter().aggregate(max_id=Max('e_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			e_id=p+1
			c_date=datetime.strptime(request.POST['lname'], "%Y-%m-%d %H:%M:%S").date()
			client_name=request.POST['age']
			C_Name=request.POST['age1']
			ph_no=request.POST['phno']
			p_name=request.POST['pname']
			c_req=request.POST['fname1']
			e_address=request.POST['add']
			e_city=request.POST['ccity']
			e_state=request.POST['cstate']
			e_country=request.POST['ccount']
			e_mail=request.POST['cemail']
			e_mail2=request.POST['cemail2']
			e_ph2=request.POST['ph12']
			e_type="IndiaMart"
			e_call_dur=request.POST['cdur']
			e_status="Open"
			e_assigned=request.POST['e_asgn']
			new_lead=inquiry_setup(e_id=e_id,e_date=c_date,client_name=client_name,C_Name=C_Name,ph_no=ph_no,p_name=p_name,c_req=c_req,e_address=e_address,e_city=e_city,e_state=e_state,e_country=e_country,e_mail=e_mail,e_mail2=e_mail2,e_ph2=e_ph2,e_type=e_type,e_call_dur=e_call_dur,e_status=e_status,e_assigned=e_assigned)
			new_lead.save()		
		#return HttpResponse("Saved")
		return HttpResponseRedirect(reverse('cus_leads_db'))
	elif request.method=='GET':
		return render(request,'add_leads.html')
	else:
		return HttpResponse('Exception Occured')

def db_leads(request):
	res = Page_itms.objects.filter().aggregate(max_id=Max('lst_items')) #this is the pagination table
	p=res.get('max_id')	
	if p is None:
		p=1
	if request.method=="POST":
		s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
		e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
		totalLeads = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').count() #count the number of leads
		indiaMartLeads = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_type='IndiaMart').filter(e_status='Assigned').count()
		convertedToParty = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Party').count()
		manualLeads=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').filter(e_type='Mannual').count()		
		data_nest=manualLeadsRequirement.objects.all()
		if request.POST['lead_type']=="All":
			fetch_type="All"
			data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned')
			
		elif request.POST['lead_type']=="Mannual":
			data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').filter(e_type='Mannual')
			
		elif request.POST['lead_type']=="IndiaMart":
			data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_type=request.POST['lead_type']).filter(e_status='Assigned')

		
		context = {'d': data,
					'd1':data_nest,
					'totalLeads':totalLeads,
					'manualleads':manualLeads,
					'indialeads':indiaMartLeads,
					'converted_customers':convertedToParty
					}
		return render(request,'db_leads.html', context)
	elif request.method=='GET':
		return render(request,'db_leads.html')
	else:
		return HttpResponse('Exception Occured')

def byUserReports(request):
	res = Page_itms.objects.filter().aggregate(max_id=Max('lst_items')) #this is the pagination table
	p=res.get('max_id')	
	if p is None:
		p=1
	if request.method=="POST":
		currentUser=str(request.user)
		str123=currentUser.find("_")
		firstName=(currentUser[0:str123])
		lastName=(currentUser[str123+1:])
		oneName=firstName+" " +lastName
		if str123<0:
			oneName=request.user
		else:
			oneName=oneName
		s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
		e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
		data_nest=manualLeadsRequirement.objects.all()
		totalLeads = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').filter(e_assigned=oneName).count() #count the number of leads
		indiaMartLeads = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_type='IndiaMart').filter(e_status='Assigned').filter(e_assigned=oneName).count()
		manualLeads=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').filter(e_type='Mannual').filter(e_assigned=oneName).count()		
		if request.POST['lead_type']=="All":
			fetch_type="All"
			data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').filter(e_assigned=oneName)
		elif request.POST['lead_type']=="Mannual":
			data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').filter(e_type='Mannual').filter(e_assigned=oneName)
			
		elif request.POST['lead_type']=="IndiaMart":
			data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_type=request.POST['lead_type']).filter(e_status='Assigned').filter(e_assigned=oneName)

		context = {'d': data,
					'd1':data_nest,
					'totalLeads':totalLeads,
					'manualleads':manualLeads,
					'indialeads':indiaMartLeads,
					'converted_customers':0
					}
		return render(request,'user_reports.html', context)
	elif request.method=='GET':
		return render(request,'user_reports.html')
	else:
		return HttpResponse('Exception Occured')

	
def convert_party_from_lead(request):
	if request.method =="POST":
			res = Person.objects.filter().aggregate(max_id=Max('cust_id'))
			p=res.get('max_id')
			if p is None:
				p=0
			c_id=p+1
			cust_code=request.POST['cust_code']
			cust_name=request.POST['cust_name']
			cust_address=request.POST['cust_address']
			cust_city=request.POST['cust_city']
			cust_pin=request.POST['cust_pin']
			cust_ph=request.POST['cust_ph']
			cust_email=request.POST['cust_email']
			cust_Gst_No=request.POST['cust_Gst_No']
			contact_per=request.POST['contact_per']
			cust_Type=request.POST['cust_Type']
			user_type=User.username
			stamp_date=datetime.now()
			new_emp=Person(cust_id=c_id,cust_code=cust_code,cust_name=cust_name,cust_address=cust_address,cust_city=cust_city,cust_ph=cust_ph,cust_Gst_No=cust_Gst_No,contact_per=contact_per,cust_Type=cust_Type,user_type=user_type,stamp_date=stamp_date,cust_pin=cust_pin)
			new_emp.save()
			t = IndiaMart_leads.objects.filter(UNIQUE_QUERY_ID=cust_code).first()
			if t is not None:
				t.e_status='Party'
				t.save()
			context={'msg':'Successfully Saved.....'
			}
			return render(request, 'user_reports.html', context)
			index(request)
	elif request.method=='GET':
		return render(request,'user_reports.html')
	else:
		return HttpResponse('Exception Occured')


def showIndiaMartData(request):
	print("executed")
	res = Page_itms.objects.filter().aggregate(max_id=Max('lst_items'))
	p=res.get('max_id')
	if request.method=="POST":
		s_date=datetime.strptime(request.POST['st1_date'], '%Y-%m-%d').date()
		e_date=datetime.strptime(request.POST['end1_date'], '%Y-%m-%d').date()
		dddd=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date])
		empnames=emp_setup.objects.all().order_by('emp_id')
		tot_leads_db = inquiry_setup.objects.filter(e_type='Unread').count()
		l1 = inquiry_setup.objects.all().count()
		
		context = {'d': dddd,'tot':l1,'dblead':tot_leads_db,'enames':empnames}
		return render(request, 'cus_index.html', context)

	elif request.method=="GET":
		dddd = Page_itms.objects.filter().aggregate(max_id=Max('lst_items'))
		l1=0
		empnames=emp_setup.objects.all().order_by('emp_id')
		tot_leads_db = inquiry_setup.objects.filter(e_type='New inquiry').count()	

		context = {'d': dddd,'tot':l1,'dblead':tot_leads_db,'enames':empnames}
		return render(request, 'cus_index.html', context)
	else:
		return HttpResponse('Exception Occured')

def fetch_new_lead_24_hours(request):
	if request.method=="POST":
		q=requests.get('https://mapi.indiamart.com/wservce/crm/crmListing/v2/?glusr_crm_key=mR22Fb9s5n7GT/ep4nCD7luLp1DNnjJn').json()
		dddd=(q['RESPONSE'])	
		l1=len(dddd)
		df=pd.DataFrame(dddd)
		print(df)
		context = {'d': dddd,'tot':l1}
		row_iter = df.iterrows()
		objs = [
		IndiaMart_leads(
		UNIQUE_QUERY_ID = row['UNIQUE_QUERY_ID'],
		QUERY_TIME  = datetime.strptime(row['QUERY_TIME'], '%Y-%m-%d %H:%M:%S').date(),
		SENDER_NAME  = row['SENDER_NAME'],
		SENDER_COMPANY  = row['SENDER_COMPANY'],
		SENDER_MOBILE  = row['SENDER_MOBILE'],
		QUERY_PRODUCT_NAME  = row['QUERY_PRODUCT_NAME'],
		QUERY_MESSAGE  = row['QUERY_MESSAGE'],
		SENDER_ADDRESS  = row['SENDER_ADDRESS'],
		SENDER_CITY  = row['SENDER_CITY'],
		SENDER_STATE  = row['SENDER_STATE'],
		SENDER_COUNTRY_ISO  = row['SENDER_COUNTRY_ISO'],
		SENDER_EMAIL  = row['SENDER_EMAIL'],
		SENDER_EMAIL_ALT  = row['SENDER_EMAIL_ALT'],
		SENDER_MOBILE_ALT  = row['SENDER_MOBILE_ALT'],
		QUERY_TYPE  = row['QUERY_TYPE'],
		CALL_DURATION  = row['CALL_DURATION'],
		e_status  = 'Unread',
		e_type  = 'IndiaMart'
		)
		for index, row in row_iter

		]
		IndiaMart_leads.objects.bulk_create(objs)
		return render(request, 'india_leads.html', context)
	elif request.method=="GET":
		return render(request, 'india_leads.html')
	else:
		return HttpResponse('Exception Occured')


def index(request):
	res = Page_itms.objects.filter().aggregate(max_id=Max('lst_items'))
	p=res.get('max_id')

	if request.method=="POST":
		s1_date=request.POST['st_date']
		e1_date=request.POST['end_date']
		s_date=datetime.strptime(request.POST['st_date'], '%Y-%m-%d').date()
		e_date=datetime.strptime(request.POST['end_date'], '%Y-%m-%d').date()
		dddd=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date])
		dddd.delete()
		empnames=emp_setup.objects.all().order_by('emp_id')
		tot_leads_db = inquiry_setup.objects.filter(e_type='New inquiry').count()			
		
		
		q=requests.get('https://mapi.indiamart.com/wservce/crm/crmListing/v2/?glusr_crm_key=mR22Fb9s5n7GT/ep4nCD7luLp1DNnjJn&start_time='+s1_date+'&end_time='+e1_date).json()
		#q=requests.get('https://mapi.indiamart.com/wservce/crm/crmListing/v2/?glusr_crm_key=mR22Fb9s5n7GT/ep4nCD7luLp1DNnjJn').json()
		dddd=(q['RESPONSE'])	
		l1=len(dddd)
		df=pd.DataFrame(dddd)
		print(df)
		context = {'d': dddd,'tot':l1,'dblead':tot_leads_db,'enames':empnames}
		row_iter = df.iterrows()
		objs = [
    	IndiaMart_leads(
        UNIQUE_QUERY_ID = row['UNIQUE_QUERY_ID'],
		QUERY_TIME  = datetime.strptime(row['QUERY_TIME'], '%Y-%m-%d %H:%M:%S').date(),
        SENDER_NAME  = row['SENDER_NAME'],
        SENDER_COMPANY  = row['SENDER_COMPANY'],
		SENDER_MOBILE  = row['SENDER_MOBILE'],
		QUERY_PRODUCT_NAME  = row['QUERY_PRODUCT_NAME'],
		QUERY_MESSAGE  = row['QUERY_MESSAGE'],
		SENDER_ADDRESS  = row['SENDER_ADDRESS'],
		SENDER_CITY  = row['SENDER_CITY'],
		SENDER_STATE  = row['SENDER_STATE'],
		SENDER_COUNTRY_ISO  = row['SENDER_COUNTRY_ISO'],
		SENDER_EMAIL  = row['SENDER_EMAIL'],
		SENDER_EMAIL_ALT  = row['SENDER_EMAIL_ALT'],
		SENDER_MOBILE_ALT  = row['SENDER_MOBILE_ALT'],
		QUERY_TYPE  = row['QUERY_TYPE'],
		CALL_DURATION  = row['CALL_DURATION'],
		e_status  = 'Unread',
		e_type  = 'IndiaMart'
    	)
    	for index, row in row_iter

		]
		IndiaMart_leads.objects.bulk_create(objs)

		return render(request, 'cus_index.html', context)

	elif request.method=="GET":
		return render(request, 'cus_index.html')
	else:
		return HttpResponse('Exception Occured')


def india_Leads(request):
	
	if request.method=="POST":
		s_date=datetime.strptime(request.POST['s_date'], '%Y-%m-%d').date()
		e_date=datetime.strptime(request.POST['e_date'], '%Y-%m-%d').date()
		
		tot_leads_db = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).count() #count the number of leads
		tot_assigned = IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date]).filter(e_status='Assigned').count() #count the assigned number of leads
		unassigned=tot_leads_db-tot_assigned
		
		data=IndiaMart_leads.objects.filter(QUERY_TIME__range=[s_date, e_date])
		
		context = {'d': data,
					'tot':tot_leads_db,
					'mlead':tot_assigned,
					'tot_india':unassigned
					}
		return render(request,'india_leads.html', context)
	elif request.method=='GET':
		return render(request,'india_leads.html')
	else:
		return HttpResponse('Exception Occured')

	#pywhatkit.sendwhatmsg_to_group_instantly("LnbLTq4EHl83txTAnbumW9", "Hey All!")
	#pywhatkit.sendwhatmsg_instantly("+918360793558", "Hi", 10)

def call_status_add(request,emp_id=0):
	if request.method =="POST":	
		res = call_status_update.objects.filter().aggregate(max_id=Max('e_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		e_id=p+1
		calledon=datetime.now()
		status=request.POST['update_status_call']
		name=emp_id
		
		new_lead=call_status_update(e_id=e_id,calledon=calledon,status=status,name=name)
		new_lead.save()		
		return render(request,'add_leads.html')
	elif request.method=='GET':
		return render(request,'add_leads.html')
	else:
		return HttpResponse('Exception Occured')


def call_status_add1(request):
	if request.method =="GET":	
		res = call_status_update.objects.filter().aggregate(max_id=Max('e_id'))
		p=res.get('max_id')
		if p is None:
			p=0
		e_id=p+1
		calledon=datetime.now()
		status=request.GET['sts']
		name= request.GET['post_id']
		new_lead=call_status_update(e_id=e_id,calledon=calledon,status=status,name=name)
		new_lead.save()
		status_db1 = call_status_update.objects.filter(name=name)		
		return JsonResponse({"data":'sas'})

def get_lead_details(request):
	if request.method == 'GET':
		post_id = request.GET['post_id']
		print(post_id)
		data=IndiaMart_leads.objects.filter(UNIQUE_QUERY_ID=post_id)
		return JsonResponse({"data":list(data.values())})