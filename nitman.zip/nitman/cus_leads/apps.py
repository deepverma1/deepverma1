from django.apps import AppConfig


class CusLeadsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cus_leads'
