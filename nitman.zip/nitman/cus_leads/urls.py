from django.contrib import admin
from django.urls import path, include
from  . import views
urlpatterns = [
    path('cus_leads', views.index, name = 'index'),
    path('cus_leads_db', views.db_leads, name = 'cus_leads_db'),
    path('fetch_new_lead_24_hours', views.fetch_new_lead_24_hours, name = 'fetch_new_lead_24_hours'),
    path('add_leads_new', views.add_leads_new, name = 'add_leads_new'),
    path('add_leads_indiamart', views.add_leads_indiamart, name = 'add_leads_indiamart'),
    path('convert_party_from_lead', views.convert_party_from_lead, name = 'convert_party_from_lead'),
    path('c_status/<int:emp_id>', views.c_status, name = 'c_status'),
    path('c_status_mail', views.c_status_mail, name = 'c_status_mail'),
    path('update_leads', views.update_leads, name = 'update_leads'),
    path('update_leads_indiamart', views.update_leads_indiamart, name = 'update_leads_indiamart'),
    path('showIndiaMartData', views.showIndiaMartData, name = 'showIndiaMartData'),
    path('india_Leads', views.india_Leads, name = 'india_Leads'),
    path('india_mart_status/<int:emp_id>', views.india_mart_status, name = 'india_mart_status'),
    path('call_status_add/<int:emp_id>', views.call_status_add, name = 'call_status_add'),
    path('call_status_add1', views.call_status_add1, name = 'call_status_add1'),
    path('byUserReports', views.byUserReports, name = 'byUserReports'),
    path('get_lead_details', views.get_lead_details, name = 'get_lead_details'),
]

