import reportlab                         # import the library
from reportlab.pdfgen import canvas      # import modules 
import os,sys
p = canvas.Canvas('1.pdf')               # Init a PDF object

for x in range(0,570):
    p.drawString(10+x, 800, "-")

for x in range(0,450):
    p.drawString(10, 800-x, "|")  

for x in range(0,450):
    p.drawString(580, 800-x, "|")   

for x in range(0,400):
    p.drawString(100+x, 800, "-")  

for x in range(0,570):
    p.drawString(10+x, 350, "-")  

p.drawString(250, 780, "Durga Poly Pack") 
p.drawString(220, 760, "Dhandari Kalan Ludhiana")  
p.drawString(220, 740, "Contact No. 9988776655") 
p.drawString(220, 720, "Contact No. 9988776655")   
for x in range(0,570):
    p.drawString(10+x, 700, "-")   
p.drawString(250, 680, "India Mart Leads")

for x in range(0,570):
    p.drawString(10+x, 660, "-")   

for x in range(0,570):
    p.drawString(10+x, 640, "-")   
p.drawString(15, 650, "India Mart Leads")

p.showPage()
p.save()
os.startfile('1.pdf','open')