from django.db import models

# Create your models here.
class inquiry_setup(models.Model):
	e_id= models.BigAutoField(primary_key=True)
	e_date=models.DateField(auto_now_add=False,auto_now=False, blank=True)
	client_name = models.CharField(max_length=100, default="")
	C_Name = models.CharField(max_length=100, default="")
	ph_no = models.CharField(max_length=11, default="")
	p_name = models.CharField(max_length=11, default="")
	c_req = models.CharField(max_length=100, default="")
	e_address=models.CharField(max_length=100, default="")
	e_city=models.CharField(max_length=100, default="")
	e_state=models.CharField(max_length=100, default="")
	e_country=models.CharField(max_length=25, default="")
	e_mail=models.CharField(max_length=100, default="")
	e_mail2=models.CharField(max_length=100, default="")
	e_ph2=models.CharField(max_length=11, default="")
	
	e_type=models.CharField(max_length=100, default="")
	e_call_dur=models.CharField(max_length=11, default="")
	
	e_status=models.CharField(max_length=50, default="")
	e_assigned=models.CharField(max_length=50, default="")
	e_transfered=models.CharField(max_length=50, default="")
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")


class IndiaMart_leads(models.Model):
	UNIQUE_QUERY_ID= models.BigAutoField(primary_key=True)
	QUERY_TIME=models.DateField(auto_now_add=False,auto_now=False, blank=True)
	SENDER_NAME = models.CharField(max_length=100, default="")
	SENDER_COMPANY = models.CharField(max_length=100, default="")
	SENDER_MOBILE = models.CharField(max_length=11, default="")
	QUERY_PRODUCT_NAME = models.CharField(max_length=11, default="")
	QUERY_MESSAGE = models.CharField(max_length=100, default="")
	SENDER_ADDRESS=models.CharField(max_length=100, default="")
	SENDER_CITY=models.CharField(max_length=100, default="")
	SENDER_STATE=models.CharField(max_length=100, default="")
	SENDER_COUNTRY_ISO=models.CharField(max_length=25, default="")
	SENDER_EMAIL=models.CharField(max_length=100, default="")
	SENDER_EMAIL_ALT=models.CharField(max_length=100, default="")
	SENDER_MOBILE_ALT=models.CharField(max_length=11, default="")
	QUERY_TYPE=models.CharField(max_length=100, default="")
	CALL_DURATION=models.CharField(max_length=11, default="")
	e_type=models.CharField(max_length=100, default="")
	e_status=models.CharField(max_length=50, default="")
	e_assigned=models.CharField(max_length=50, default="")
	e_transfered=models.CharField(max_length=50, default="")
	e_with_reference=models.CharField(max_length=50, default="")
	e_by_name=models.CharField(max_length=50, default="")
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")
	

class mailsdb1(models.Model):
	name = models.CharField(max_length=100, default="")
	email = models.CharField(max_length=100, default="")
	subject = models.CharField(max_length=100, default="")
	body = models.CharField(max_length=100, default="")
	ddate=models.CharField(max_length=100, default="")

class sent_mails(models.Model):
	name = models.CharField(max_length=100, default="")
	email = models.CharField(max_length=100, default="")
	subject = models.CharField(max_length=100, default="")
	body = models.CharField(max_length=100, default="")
	ddate=models.CharField(max_length=100, default="")
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")

class call_status_update(models.Model):
	e_id= models.BigAutoField(primary_key=True)
	name = models.CharField(max_length=100, default="")
	status = models.CharField(max_length=100, default="")
	s_date = models.CharField(max_length=100, default="")
	remarks = models.CharField(max_length=100, default="")
	calledon=models.CharField(max_length=100, default="")
	e_field2=models.CharField(max_length=100, default="")
	e_field3=models.CharField(max_length=100, default="")
	e_field4=models.CharField(max_length=100, default="")
	user_type=models.CharField(max_length=50, default="")
	stamp_date=models.CharField(max_length=50, default="")

class manualLeadsRequirement(models.Model):
	e_id= models.BigAutoField(primary_key=True)
	l_no=models.IntegerField(default=0)
	name = models.CharField(max_length=100, default="")
	c_name = models.CharField(max_length=100, default="")
	product_tt = models.CharField(max_length=100, default="")
	requirement = models.CharField(max_length=100, default="")
	

